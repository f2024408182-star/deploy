from fastapi import FastAPI, HTTPException, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
import os
from supabase import create_client, Client

# ─────────────────────────────────────────────
#  App Setup
# ─────────────────────────────────────────────
app = FastAPI(
    title="Student Management System API",
    description="Full Stack Project – OSSD Y9 | UMT",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────
#  Supabase Connection
#  Set these in your .env or Railway/Render env vars
# ─────────────────────────────────────────────
SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://your-project.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "your-anon-key")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# ─────────────────────────────────────────────
#  Pydantic Schemas
# ─────────────────────────────────────────────

class StudentCreate(BaseModel):
    name: str
    email: str
    roll_no: str
    department: str
    semester: int
    cgpa: Optional[float] = None

class StudentUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    department: Optional[str] = None
    semester: Optional[int] = None
    cgpa: Optional[float] = None

class UserRegister(BaseModel):
    username: str
    email: str
    password: str          # store hashed in real apps!

class UserLogin(BaseModel):
    email: str
    password: str


# ─────────────────────────────────────────────
#  Root
# ─────────────────────────────────────────────

@app.get("/", tags=["Root"])
def root():
    """Health check / welcome endpoint."""
    return {
        "message": "Student Management System API is running!",
        "docs": "/docs",
        "version": "1.0.0"
    }


# ─────────────────────────────────────────────
#  AUTH ENDPOINTS  (Endpoints 1 & 2)
# ─────────────────────────────────────────────

@app.post("/register", tags=["Auth"])
def register_user(user: UserRegister):
    """Create a new admin/teacher account."""
    existing = supabase.table("users").select("*").eq("email", user.email).execute()
    if existing.data:
        raise HTTPException(status_code=400, detail="Email already registered.")

    result = supabase.table("users").insert({
        "username": user.username,
        "email": user.email,
        "password": user.password,   # hash with bcrypt in production!
        "created_at": datetime.utcnow().isoformat()
    }).execute()

    return {"message": "User registered successfully.", "user": result.data}


@app.post("/login", tags=["Auth"])
def login_user(credentials: UserLogin):
    """Authenticate a user and return a simple success response."""
    result = supabase.table("users").select("*") \
        .eq("email", credentials.email) \
        .eq("password", credentials.password) \
        .execute()

    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    return {"message": "Login successful.", "user": result.data[0]}


# ─────────────────────────────────────────────
#  STUDENT CRUD ENDPOINTS  (Endpoints 3 – 9)
# ─────────────────────────────────────────────

@app.post("/students", tags=["Students"])
def add_student(student: StudentCreate):
    """Endpoint 3 – Add a new student record."""
    # Check duplicate roll_no
    check = supabase.table("students").select("*").eq("roll_no", student.roll_no).execute()
    if check.data:
        raise HTTPException(status_code=400, detail="Roll number already exists.")

    result = supabase.table("students").insert({
        **student.dict(),
        "created_at": datetime.utcnow().isoformat()
    }).execute()

    return {"message": "Student added successfully.", "student": result.data}


@app.get("/students", tags=["Students"])
def get_all_students():
    """Endpoint 4 – Retrieve all student records."""
    result = supabase.table("students").select("*").order("name").execute()
    return {"students": result.data, "total": len(result.data)}


@app.get("/students/{student_id}", tags=["Students"])
def get_student(student_id: int):
    """Endpoint 5 – Retrieve a single student by ID."""
    result = supabase.table("students").select("*").eq("id", student_id).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Student not found.")
    return {"student": result.data[0]}


@app.put("/students/{student_id}", tags=["Students"])
def update_student(student_id: int, student: StudentUpdate):
    """Endpoint 6 – Update student information."""
    # Check exists
    check = supabase.table("students").select("id").eq("id", student_id).execute()
    if not check.data:
        raise HTTPException(status_code=404, detail="Student not found.")

    update_data = {k: v for k, v in student.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields provided to update.")

    result = supabase.table("students").update(update_data).eq("id", student_id).execute()
    return {"message": "Student updated successfully.", "student": result.data}


@app.delete("/students/{student_id}", tags=["Students"])
def delete_student(student_id: int):
    """Endpoint 7 – Delete a student record."""
    check = supabase.table("students").select("id").eq("id", student_id).execute()
    if not check.data:
        raise HTTPException(status_code=404, detail="Student not found.")

    supabase.table("students").delete().eq("id", student_id).execute()
    return {"message": f"Student {student_id} deleted successfully."}


# ─────────────────────────────────────────────
#  SEARCH & FILTER  (Endpoints 8 & 9)
# ─────────────────────────────────────────────

@app.get("/students/search/query", tags=["Search"])
def search_students(name: str = Query(..., description="Search by student name")):
    """Endpoint 8 – Search students by name (partial match)."""
    result = supabase.table("students").select("*").ilike("name", f"%{name}%").execute()
    return {"results": result.data, "total": len(result.data)}


@app.get("/students/filter/department", tags=["Search"])
def filter_by_department(department: str = Query(..., description="Filter by department")):
    """Endpoint 9 – Filter students by department."""
    result = supabase.table("students").select("*").eq("department", department).execute()
    return {"results": result.data, "total": len(result.data)}


# ─────────────────────────────────────────────
#  DASHBOARD / STATISTICS  (Endpoint 10)
# ─────────────────────────────────────────────

@app.get("/dashboard/stats", tags=["Dashboard"])
def get_dashboard_stats():
    """Endpoint 10 – Aggregate statistics for the dashboard."""
    all_students = supabase.table("students").select("*").execute().data
    total = len(all_students)

    # Department-wise count
    dept_count: dict = {}
    cgpa_sum = 0
    cgpa_count = 0

    for s in all_students:
        dept = s.get("department", "Unknown")
        dept_count[dept] = dept_count.get(dept, 0) + 1
        if s.get("cgpa"):
            cgpa_sum += s["cgpa"]
            cgpa_count += 1

    avg_cgpa = round(cgpa_sum / cgpa_count, 2) if cgpa_count else 0

    # Total users
    total_users = len(supabase.table("users").select("id").execute().data)

    return {
        "total_students": total,
        "total_users": total_users,
        "average_cgpa": avg_cgpa,
        "students_by_department": dept_count,
    }


# ─────────────────────────────────────────────
#  BONUS: Get students by semester  (Endpoint 11)
# ─────────────────────────────────────────────

@app.get("/students/filter/semester", tags=["Search"])
def filter_by_semester(semester: int = Query(..., description="Filter by semester number")):
    """Endpoint 11 – Filter students by semester."""
    result = supabase.table("students").select("*").eq("semester", semester).execute()
    return {"results": result.data, "total": len(result.data)}
