# Student Management System
**Final Semester Project – OSSD Y9 | University of Management and Technology**

---

## Project Overview
A full-stack web application to manage student records. Built with FastAPI (Python), Supabase (PostgreSQL), and plain HTML/CSS/JavaScript.

---

## Tech Stack
| Layer     | Technology              |
|-----------|-------------------------|
| Backend   | FastAPI (Python 3.11)   |
| Database  | PostgreSQL via Supabase |
| Frontend  | HTML, CSS, JavaScript   |
| Deployment| Render (backend), Vercel (frontend) |

---

## Folder Structure
```
FinalProject/
├── frontend/
│   └── index.html          ← All 5 pages (Home, About, Login, Dashboard, Manage)
├── backend/
│   ├── main.py             ← All 11 API endpoints
│   ├── requirements.txt
│   └── .env                ← (do NOT push to GitHub)
├── screenshots/
└── README.md
```

---

## API Endpoints (11 Total)

| # | Method | Endpoint                        | Purpose              |
|---|--------|---------------------------------|----------------------|
| 1 | POST   | `/register`                     | Register admin user  |
| 2 | POST   | `/login`                        | Login user           |
| 3 | POST   | `/students`                     | Add student          |
| 4 | GET    | `/students`                     | Get all students     |
| 5 | GET    | `/students/{id}`                | Get one student      |
| 6 | PUT    | `/students/{id}`                | Update student       |
| 7 | DELETE | `/students/{id}`                | Delete student       |
| 8 | GET    | `/students/search/query?name=`  | Search by name       |
| 9 | GET    | `/students/filter/department?`  | Filter by department |
|10 | GET    | `/dashboard/stats`              | Dashboard statistics |
|11 | GET    | `/students/filter/semester?`    | Filter by semester   |

---

## Database Setup (Supabase)

1. Go to [supabase.com](https://supabase.com) → Create a new project
2. Open **SQL Editor** and run:

```sql
-- Users table (admins)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Students table
CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    roll_no TEXT UNIQUE NOT NULL,
    department TEXT NOT NULL,
    semester INTEGER NOT NULL,
    cgpa FLOAT,
    created_at TIMESTAMP DEFAULT NOW()
);
```

3. Go to **Settings → API** → Copy your **Project URL** and **anon/public key**

---

## Backend Setup (Local)

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create .env file
echo "SUPABASE_URL=https://your-project.supabase.co" > .env
echo "SUPABASE_KEY=your-anon-key" >> .env

# 4. Run the server
uvicorn main:app --reload
```

Open: `http://localhost:8000/docs` to see all API endpoints.

---

## requirements.txt

```
fastapi==0.111.0
uvicorn==0.30.1
supabase==2.5.1
python-dotenv==1.0.1
pydantic==2.7.1
```

---

## Backend Deployment (Render)

1. Push your code to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Set:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port 10000`
5. Add Environment Variables:
   - `SUPABASE_URL` → your Supabase URL
   - `SUPABASE_KEY` → your Supabase anon key
6. Deploy → Copy the live URL

---

## Frontend Deployment (Vercel)

1. Go to [vercel.com](https://vercel.com) → New Project
2. Upload/import your `frontend/` folder
3. Deploy → Get your live link
4. Update `API_URL` in `index.html` with your Render backend URL

---

## Final Submission Checklist

- [x] Documentation PDF (Phase 1)
- [x] 5 Frontend pages (Home, About, Login, Dashboard, Manage)
- [x] 11 Backend API endpoints
- [x] Full CRUD functionality
- [x] Supabase PostgreSQL database
- [x] Project deployed online
- [x] GitHub repository
- [x] README with setup instructions
- [x] Screenshots folder

---

## Viva Preparation – Quick Answers

**Q: What problem does this solve?**
Manual tracking of student records is slow and error-prone. This system centralizes all data with a searchable, updatable interface.

**Q: Which database did you use and why?**
PostgreSQL via Supabase — it's relational, free to host, and integrates easily with FastAPI.

**Q: How does FastAPI connect to the database?**
Using the `supabase-py` client library with environment variables for the URL and key.

**Q: Where is the backend deployed?**
Render (free tier, auto-deploys from GitHub).

**Q: Where is the database hosted?**
Supabase (free tier PostgreSQL).

---

*Project by: [Your Name] | Roll No: [Your Roll No] | OSSD Y9 | UMT 2026*
